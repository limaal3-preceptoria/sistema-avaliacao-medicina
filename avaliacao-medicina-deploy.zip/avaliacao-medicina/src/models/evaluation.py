from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class HealthUnit(db.Model):
    __tablename__ = 'health_units'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    groups = db.relationship('StudentGroup', backref='health_unit', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Preceptor(db.Model):
    __tablename__ = 'preceptors'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    groups = db.relationship('StudentGroup', backref='preceptor', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Student(db.Model):
    __tablename__ = 'students'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    registration = db.Column(db.String(50), unique=True, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    group_memberships = db.relationship('GroupMembership', backref='student', lazy=True)
    evaluations = db.relationship('Evaluation', backref='student', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'registration': self.registration,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class StudentGroup(db.Model):
    __tablename__ = 'student_groups'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    period = db.Column(db.String(50), nullable=False)  # Ex: "8ª ETAPA"
    year = db.Column(db.Integer, nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    health_unit_id = db.Column(db.Integer, db.ForeignKey('health_units.id'), nullable=False)
    preceptor_id = db.Column(db.Integer, db.ForeignKey('preceptors.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    memberships = db.relationship('GroupMembership', backref='group', lazy=True)
    evaluation_dates = db.relationship('EvaluationDate', backref='group', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'period': self.period,
            'year': self.year,
            'semester': self.semester,
            'health_unit_id': self.health_unit_id,
            'preceptor_id': self.preceptor_id,
            'health_unit': self.health_unit.to_dict() if self.health_unit else None,
            'preceptor': self.preceptor.to_dict() if self.preceptor else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class GroupMembership(db.Model):
    __tablename__ = 'group_memberships'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    group_id = db.Column(db.Integer, db.ForeignKey('student_groups.id'), nullable=False)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'student_id': self.student_id,
            'group_id': self.group_id,
            'student': self.student.to_dict() if self.student else None,
            'joined_at': self.joined_at.isoformat() if self.joined_at else None
        }

class EvaluationDate(db.Model):
    __tablename__ = 'evaluation_dates'
    
    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey('student_groups.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    description = db.Column(db.String(200), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    evaluations = db.relationship('Evaluation', backref='evaluation_date', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'group_id': self.group_id,
            'date': self.date.isoformat() if self.date else None,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Evaluation(db.Model):
    __tablename__ = 'evaluations'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    evaluation_date_id = db.Column(db.Integer, db.ForeignKey('evaluation_dates.id'), nullable=False)
    
    # Notas das três dimensões (0-10)
    attitude_score = db.Column(db.Float, nullable=True)  # ATITUDE
    skill_score = db.Column(db.Float, nullable=True)     # HABILIDADE
    cognition_score = db.Column(db.Float, nullable=True) # COGNIÇÃO
    
    # Observações
    observations = db.Column(db.Text, nullable=True)
    
    # Metadados
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'student_id': self.student_id,
            'evaluation_date_id': self.evaluation_date_id,
            'attitude_score': self.attitude_score,
            'skill_score': self.skill_score,
            'cognition_score': self.cognition_score,
            'observations': self.observations,
            'student': self.student.to_dict() if self.student else None,
            'evaluation_date': self.evaluation_date.to_dict() if self.evaluation_date else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def get_average_score(self):
        """Calcula a média das três dimensões"""
        scores = [self.attitude_score, self.skill_score, self.cognition_score]
        valid_scores = [score for score in scores if score is not None]
        return sum(valid_scores) / len(valid_scores) if valid_scores else None

